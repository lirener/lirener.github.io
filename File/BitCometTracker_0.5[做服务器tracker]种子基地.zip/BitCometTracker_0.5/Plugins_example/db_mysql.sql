--This file is used to create Tables and Store Procedure in mysql database 

CREATE TABLE `hashinfotemp` (
  `metaid` int(11) NOT NULL default '0',
  `HashInfo` varchar(40) NOT NULL default '',
  `isAdd` tinyint(1) NOT NULL default '0'
) TYPE=MyISAM;


CREATE TABLE `metatable` (
  `id` int(11) NOT NULL auto_increment,
  `category` int(11) NOT NULL default '0',
  `hashinfo` varchar(40) NOT NULL default '',
  `filename` varchar(250) NOT NULL default '',
  `description` mediumtext NOT NULL,
  `torrenturl` varchar(250) NOT NULL default '',
  `offer` varchar(50) NOT NULL default '',
  `publisherid` int(11) NOT NULL default '0',
  `filesize` int(11) NOT NULL default '0',
  `tracker` mediumtext NOT NULL,
  `subject` varchar(250) NOT NULL default '',
  `other_url` varchar(250) NOT NULL default '',
  `Auditing` tinyint(1) NOT NULL default '0',
  `publishtime` datetime NOT NULL default '0000-00-00 00:00:00',
  `to_top` char(1) NOT NULL default '',
  `member` char(1) NOT NULL default '',
  `hide` char(1) NOT NULL default '',
  `localTF` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM ;


CREATE TABLE `trackerstatus` (
  `InfoHash` char(40) binary NOT NULL default '0',
  `CompletedNum` int(10) unsigned NOT NULL default '0',
  `PeerNum` int(10) unsigned NOT NULL default '0',
  `SeederNum` int(10) unsigned NOT NULL default '0',
  `UpdateTime` timestamp(14) NOT NULL,
  PRIMARY KEY  (`InfoHash`),
  UNIQUE KEY `InfoHash` (`InfoHash`)
) TYPE=MyISAM;
