BitCometTracker
================
BitCometTracker is a high performance bittorrent tracker with a lot of enhancement. BitCometServer supports both HTTP and UDP tracker protocols, database plugins, and multi-port listening. BitCometServer is tested under heavy load, over 80,000 torrents and 800,000 users. SDK sample of the datebase plugin is also provided.


Feature
================
1. High performance, highly scalable
2. Easy GUI configuration, simple interface
3. Able to listen to serveral ports
4. Support both TCP and UDP tracker protocol
5. Working with BitComet Client perfectly
6. Remote monitor the performance using web browser
7. Able to update database, plugin SDK is provided


License
================
Copyright (C) 2004-2006 BitComet.com <bitcomet@yahoo.com>
Please refer to license.txt for more details.


OS Support
================
Windows 2000, Windows XP and Windows 2003.


Installation/Uninstall
======================
unzip and run. no need to install.


Settings
==============
Click config button to show "config" dialog

	Help                Help linked to BitComet.com
	Authentication      Enable/disable authentication mode
	TCP Port            TCP ports the tracker is listening on, can be more than one port, 
	                    seperated by whitespace, comma, semicolon, and other seperators, 
	                    leave blank to disable TCP listening
	UDP Port            UDP ports the tracker is listening on, can be more than one port,
	                    seperated by whitespace, comma, semicolon, and other seperators, 
	                    leave blank to disable UDP listening
	Send udp annouce address in tcp response
	                    send udp annouce address for the TCP request, suggesting the existence
	                    of UDP listening port, hoping the client to use UDP tracker protocol
	Optimized Number    estimated peer number to optimize the performance
	Statistics Port     TCP ports the tracker is listening on for HTTP remote monitor
	                    please make sure it is different from the above TCP Ports
	                    leave blank to disable remote monitor
	Statistics Path     HTTP Path for remote monitor, starting with /, e.g. /stats
	                    the remote monitor URL looks like this
	                        http://<host ip or host name>:<Statistics Port><Statistics Path>
	Scrape Path         HTTP Path for scrape, starting with /, e.g. /scrape
	Datebase
		Connection String     Connection string passed to db_connect function while using database plugin
		Flush Interval        Interval for updating to database
		Fetch Interval        Interval for fetching new data from database


Plugins Example
===============
An example plugin source code is given in .\Plugins_SDK. 
Please refer to .\Plugins_SDK\Plugin_Readme.txt for detail plugin develop infomation.
The compiled dll is in .\plugins_example. To make it work, please follow the instructions below:

1. Copy plugins_example/libmySQL.dll to be with BitCometTracker.exe
2. Copy plugins_example/db_mysql.dll to plugins/
3. Import plugins_example/db_mysql.sql to mysql database to create table
4. run the BitCometTracker.exe, click config and set Datebase Connection String: host:user:passwd:db_name according your mysql server.
5. click RUN!



Further information
======================
Homepage:   http://www.bitcomet.com/
Forum   :   http://forums.bitcomet.com/

