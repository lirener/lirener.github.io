What is Database Plugin
========================
1. is a dll file whose name is starting with db_
2. must be placed in the sub-directory /Plugins
3. has 6 export functions, whose prototypes are
    BOOL  DLL_CALL_TYPE db_connect(LPSTR);
    BOOL  DLL_CALL_TYPE db_update(const unsigned char* , int, int, int);
    BOOL  DLL_CALL_TYPE db_disconnect();
    int   DLL_CALL_TYPE db_fetch(info_list_t** phead);
    int   DLL_CALL_TYPE db_fetch2(info_list_t** phead);
    char* DLL_CALL_TYPE db_get_plugin_interface_version();
where
    DLL_CALL_TYPE is the Calling Convention, and MUST be defined as below:
    #define DLL_CALL_TYPE __fastcall

    info_list_t is a info_hash singly linked list struct:
    typedef struct info_list_s {
      struct info_list_s  *next;
      char info[40];
    }info_list_t;     

function description:      
    db_connect       to connect to database, its parameter is just a char string passing connection string
    db_update        to update database, parameters from left to right are 
                     info_hash, number of completed peers, number of active peers, number of active seeders
    db_fetch         to fetch all records of hashinfo from database for first time, parameter is  a null 
                     pointer to a info_hash singly linked list pointer. BCTracker will release this list.
    db_fetch2        to fetch added records or deleted records of infohash since db_fetch() from database,  
                     parameter is a null pointer to a info_hash singly linked list pointer. BCTracker will 
                     release this list.
    db_disconnect    to close the connection
    db_get_plugin_interface_version
                     to return which version of BitCometTracker is compatible with this plug-in dll.
                     "0.3" is requied to return to work with this release of BitCometTracker.
    
  
How to Write
=============
Taking plugin_sdk/db_mysql as example:
  1. A devlope package provided by mysql is needed before compiling this example, including header files, 
     library files, and dll files. You can obtain them by installing windows version mysql package from 
     http://dev.mysql.com/downloads/index.html. We also include the sdk of version 4.0.27 in plugin_sdk/db_mysql/mysql.
  2. Add header files directory to "include files" of Visual Studio project options; Add lib files directory 
     to "library files" of Visual Studio project options.
  3. Write .def file to define export symbols, and define it as "Module definaiton file" in linker options.
  4. Build project. Copy the generated db_mysql.dll to .\Plugins. Then copy libmySQL.dll to the folder where 
     BitCometTracker.exe located or %windows%\system32.
  5. Setup Datebase_Connection_String in config dialog of BitCometTracker. 
     using mysql, the Datebase_Connection_String format is "host:user:passwd:db_name"
     using ADO, you can use ADO connection string directly, details refer to ado_conn.txt.
     example: "provider=sqloledb;data source=127.0.0.1;initial catagory=bt;user id=sa;password=123456"

