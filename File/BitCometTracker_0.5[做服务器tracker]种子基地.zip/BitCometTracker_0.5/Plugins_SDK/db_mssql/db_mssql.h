#define DLL_EXPORT_API __declspec(dllexport)
#define DLL_CALL_TYPE __fastcall

typedef struct info_list_s {
	struct info_list_s	*next;
	char info[40];
}info_list_t;
	
DLL_EXPORT_API BOOL		DLL_CALL_TYPE db_connect(LPSTR);
DLL_EXPORT_API BOOL		DLL_CALL_TYPE db_disconnect();
DLL_EXPORT_API BOOL		DLL_CALL_TYPE db_update(const unsigned char*, int, int, int);
DLL_EXPORT_API int		DLL_CALL_TYPE db_fetch(info_list_t** add_list_head, BOOL need_auth);
DLL_EXPORT_API int		DLL_CALL_TYPE db_fetch2(info_list_t** add_list_head, info_list_t** delete_list_head);
DLL_EXPORT_API char*	DLL_CALL_TYPE db_get_plugin_interface_version();
